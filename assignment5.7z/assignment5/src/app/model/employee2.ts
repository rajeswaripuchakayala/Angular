export interface empList{
    "id": number,
    "employee_name": string,
    "employee_salary": number,
    "employee_age": number
}